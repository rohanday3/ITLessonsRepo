
import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.Scanner;


public class Donated extends javax.swing.JFrame {
  DecimalFormat d = new DecimalFormat("0.00");    
  String[] donorsArr = {"BEK709","BOE145","DOJ654","KHA103","MKS867","NAA854","SAL980","SIR654","SMA678"};
  int[] year = {2014,2015,2016};
  double[][] futureD = {{1550.00,0,0},{885.00,0,0},{905.00,0,0},{1420.00,0,0},{1880.00,0,0},{3500.00,0,0},{1050.00,0,0},{1800.00,0,0},{230.00,0,0}};
          
    
    public Donated() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        cbxDonorCode = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        txaQ4 = new javax.swing.JTextArea();
        DisplayTableOfDonors = new javax.swing.JButton();
        EstimatedDonations = new javax.swing.JButton();
        Exit = new javax.swing.JButton();
        Display = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 204));

        cbxDonorCode.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "BEK709", "BOE145", "DOJ654", "KHA103", "MKS867", "NAA854", "SAL980", "SIR654", "SMA678", " " }));
        cbxDonorCode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxDonorCodeActionPerformed(evt);
            }
        });

        txaQ4.setColumns(20);
        txaQ4.setRows(5);
        jScrollPane1.setViewportView(txaQ4);

        DisplayTableOfDonors.setText("Display Table of Donors");
        DisplayTableOfDonors.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisplayTableOfDonorsActionPerformed(evt);
            }
        });

        EstimatedDonations.setText("Calculate Estimated 2015/2016 donations per Donor");
        EstimatedDonations.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EstimatedDonationsActionPerformed(evt);
            }
        });

        Exit.setText("Exit");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });

        Display.setText("Display");
        Display.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisplayActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cbxDonorCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Display))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(DisplayTableOfDonors)))
                .addContainerGap(26, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(EstimatedDonations)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Exit))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(cbxDonorCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(Display)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 339, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addComponent(DisplayTableOfDonors)
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EstimatedDonations)
                    .addComponent(Exit))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DisplayTableOfDonorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisplayTableOfDonorsActionPerformed
        for(int y = 0; y < 3;y++)
        {
            txaQ4.append("\t"+year[y]);
        }
        txaQ4.append("\n---------------------------------------------------------------------------------\n");
        txaQ4.append("\n");
        
        for(int r = 0; r < 9; r++)
        {
            txaQ4.append(donorsArr[r]+"\t");
            for(int c = 0; c < 3;c++)
            {
                txaQ4.append("R"+d.format(futureD[r][c])+"\t");
                
            }
            txaQ4.append("\n");
        }
    }//GEN-LAST:event_DisplayTableOfDonorsActionPerformed

    private void EstimatedDonationsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EstimatedDonationsActionPerformed
       txaQ4.append("Current and Estimated Donations for 2015 and 2016\n");
       txaQ4.append("---------------------------------------------------------------------------------\n");
        for(int r = 0; r < 9; r++)
       {
           for(int c = 1; c < 3; c++)
           {
               futureD[r][c] = futureD[r][c-1]*1.1;
           }
       }
    }//GEN-LAST:event_EstimatedDonationsActionPerformed

    private void cbxDonorCodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxDonorCodeActionPerformed
       
    }//GEN-LAST:event_cbxDonorCodeActionPerformed

    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitActionPerformed
          System.exit(0);
    }//GEN-LAST:event_ExitActionPerformed

    private void DisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisplayActionPerformed
       char cash =' ';
        double total = 0;
        String selecteddonor = (String)cbxDonorCode.getSelectedItem();
        File f = new File("AmountReceived.txt");
        
        if(!f.exists())
        {
            System.out.println("File Not Found");
            System.exit(0);
        }
        try{
            Scanner sc = new Scanner(f);
            
            while(sc.hasNextLine())
            {
                String line = sc.nextLine(); 
                Scanner split = new Scanner(line).useDelimiter(",|#");
                
                String tanum = split.next();
                String donor = split.next();
                String date = split.next();
                double amount  = Integer.parseInt(split.next());
                String type = split.next();
                
                if(selecteddonor.equals(donor))
                {
                    if(type.equalsIgnoreCase("CASH"))
                        cash = '*';
                   txaQ4.append(date+"  R "+amount+cash+"\n");
                   total = total + amount;
                   cash = ' ';
                }
             
                
            }
            String t = String.format("%2.2f",total);
            txaQ4.append("Total Donated : R "+t+"\n");
            txaQ4.append("--------------------------------\n");
            }
        catch(FileNotFoundException ex)
        {
            System.out.println("File Cannot be found");
        }  
    }//GEN-LAST:event_DisplayActionPerformed

   
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Donated().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Display;
    private javax.swing.JButton DisplayTableOfDonors;
    private javax.swing.JButton EstimatedDonations;
    private javax.swing.JButton Exit;
    private javax.swing.JComboBox cbxDonorCode;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txaQ4;
    // End of variables declaration//GEN-END:variables
}
