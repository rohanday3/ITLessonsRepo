
import java.util.Calendar;

public class vaccines {
    
  private int month;
  private String vac1;
  private String vac2;
  private String vac3;

    public vaccines() {
    }

    public vaccines(int month, String vac1, String vac2, String vac3) {
        this.month = month;
        this.vac1 = vac1;
        this.vac2 = vac2;
        this.vac3 = vac3;
    }

    @Override
    public String toString() {
        return "Vaccines \n" + "Month=" + month + "\n " + vac1 + "\n " + vac2 + "\n " + vac3 ;
    }

   public boolean ValidateDOB(int yearc, int monthc)
   {
       boolean val = false;
       Calendar now = Calendar.getInstance();
      
       int year = now.getWeekYear();   
              
       if(yearc == year)
       {
           int monthn = (now.get(Calendar.MONTH)+1);         
                      
           if((monthn - monthc) == month)
           {
               val = true;
               
           }
       }
       return val;
   }
     
    
}
