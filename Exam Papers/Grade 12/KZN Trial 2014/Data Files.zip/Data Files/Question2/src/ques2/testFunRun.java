
package ques2;

public class testFunRun extends javax.swing.JFrame
{
   
    public testFunRun()
    {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jLayeredPane1 = new javax.swing.JLayeredPane();
        btnButton1 = new javax.swing.JButton();
        btnButton2 = new javax.swing.JButton();
        btnButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txaDisplay = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnButton1.setText("Button1");
        btnButton1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnButton1ActionPerformed(evt);
            }
        });
        btnButton1.setBounds(20, 20, 90, 23);
        jLayeredPane1.add(btnButton1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnButton2.setText("Button2");
        btnButton2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnButton2ActionPerformed(evt);
            }
        });
        btnButton2.setBounds(20, 70, 90, 23);
        jLayeredPane1.add(btnButton2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnButton3.setText("Button3");
        btnButton3.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnButton3ActionPerformed(evt);
            }
        });
        btnButton3.setBounds(20, 120, 90, 23);
        jLayeredPane1.add(btnButton3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        txaDisplay.setEditable(false);
        txaDisplay.setColumns(20);
        txaDisplay.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        txaDisplay.setRows(5);
        jScrollPane1.setViewportView(txaDisplay);

        jScrollPane1.setBounds(120, 20, 750, 350);
        jLayeredPane1.add(jScrollPane1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 879, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 393, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnButton1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnButton1ActionPerformed
    {//GEN-HEADEREND:event_btnButton1ActionPerformed
       
    }//GEN-LAST:event_btnButton1ActionPerformed

    private void btnButton2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnButton2ActionPerformed
    {//GEN-HEADEREND:event_btnButton2ActionPerformed

    }//GEN-LAST:event_btnButton2ActionPerformed

    private void btnButton3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnButton3ActionPerformed
    {//GEN-HEADEREND:event_btnButton3ActionPerformed

    }//GEN-LAST:event_btnButton3ActionPerformed
    
    public static void main(String args[])
    {
        new testFunRun().setVisible(true);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnButton1;
    private javax.swing.JButton btnButton2;
    private javax.swing.JButton btnButton3;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txaDisplay;
    // End of variables declaration//GEN-END:variables
}
