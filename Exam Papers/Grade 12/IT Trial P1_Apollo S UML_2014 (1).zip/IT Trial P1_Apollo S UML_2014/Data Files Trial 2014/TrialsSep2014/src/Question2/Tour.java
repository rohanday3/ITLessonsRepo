package Question2;




/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author naren_000
 */
public class Tour {
  
    private String gName;
    private String dName;
    private String mName;
    private int numD;
    private int numT;
    private double tariff;

    public Tour() {
    }
   
}

