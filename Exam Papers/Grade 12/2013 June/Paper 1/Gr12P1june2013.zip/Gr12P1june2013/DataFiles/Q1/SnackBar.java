   import java.util.Scanner;
   import java.sql.SQLException;

   public class SnackBar
   {
      public static void main (String[] args) throws SQLException
      {
         Scanner kb = new Scanner(System.in);
      
         dbClass db = new dbClass();
      	
         String sql="";
      	
         System.out.println();
         
         char choice = ' '; 
         do
         {         
            System.out.println();        
            System.out.println();
            System.out.println("       MENU");
            System.out.println();
            System.out.println("    A - All Items");
            System.out.println("    B - Items with no Size");
            System.out.println("    C - Number of Items for Brand");
            System.out.println("    D - Removal of Products");
            System.out.println("    E - Gum");
            System.out.println("    F - Category Average Selling Price");
            System.out.println("    G - Old Snacks");
            System.out.println("    H - Re - Order List");
            System.out.println();
            System.out.println("    Q - QUIT");
            System.out.println();
            System.out.print("    Your Choice? ");
            choice = kb.nextLine().toUpperCase().charAt(0);
            System.out.println();
            switch(choice)
            {
               case 'A':
                  {
                     sql=" ";
                  	  
                     db.query(sql);
                     break;
                  }
               
               case 'B':
                  {
                     sql=" ";
                  	  
                     db.query(sql);              
                  	
                     break;
                  }
               
               case 'C':
                  {                  	
                                       	
                     sql=" ";
                  	  
                     db.query(sql);              
                  	
                     break;
                  }
               
               case 'D':
                  {
                     sql=" ";
                  	   
                     db.query(sql);
                     
                     break;
                  }  
               
               case 'E':
                  {
                     sql=" ";
                  	  
                     db.query(sql);
                  	
                     break;
                  }                 
                                    
               case 'F':
                  {
                                 
                     sql=" ";
                  	  
                     db.query(sql);
                  	
                     break;
                  }  
               
               case 'G':
                  {
                     sql=" ";
                  
                     db.query(sql);
                  	
                     break;
                  }   
               
               case 'H':
                  {
                     sql=" "; 
                  	 
                     db.query(sql);
                  	
                     break;
                  }   
                                              	
               case 'Q':
                  {
                     db.disconnect();
                     System.out.println();                        
                     System.out.println("Done");  
                  
                     break;
                  }
               
               default:
                  {
                     System.out.println();          
                     System.out.println("Invalid Option!");
                     
                     break;
                  }
            				
            }
         }
          while (choice != 'Q');    
      
            
      }
   }