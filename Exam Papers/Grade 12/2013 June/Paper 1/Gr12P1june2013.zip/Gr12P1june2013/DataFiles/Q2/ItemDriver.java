import java.util.Scanner;   
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.File;
import java.io.FileReader;

public class ItemDriver
{
	public static void main(String args[]) throws Exception
	{

		Scanner kb = new Scanner(System.in);
		
		char ch = ' ';
		while (ch != 'Q')
		{
		
			System.out.println();
			System.out.println("              Menu");
			System.out.println(" ");
			System.out.println("       A - Calculate Selling Price");
			System.out.println("       B - Display"); 
			System.out.println("       C - Sort");
			System.out.println("       D - Search for Items by Specific Brand");
			System.out.println(" ");
			System.out.println("       Q - QUIT");
			System.out.println(" ");
			System.out.print("       Your choice? : ");
		
		   ch = kb.nextLine().toUpperCase().charAt(0);
			switch (ch)
			{
				case 'A':
				{					
					
					break;
				}
			
				case 'B':
				{
					
					break; 
				}
			
				case 'C':
				{
					
					break; 
				} 
				
				case 'D':
				{
				
				   break;
				}	
 
				case 'Q':
				{
					System.exit(0);
				} // case
				
			} // switch
			
		} // while
		
	} // main
	
} // class