public class Farms
{
   private String farmName;
   private double space;
   private int proteas;
   private char status;

   public Farms(String farmName, double space, int proteas, char status)
   {
      this.farmName = farmName;
      this.space = space;
      this.proteas = proteas;
      this.status = status;
   }

   public String getFarmName()
   {
      return farmName;
   }

   public char getStatus()
   {
      return status;
   }

   public int getProteas()
   {
      return proteas;
   }

   public void setStatus(char status)
   {
      this.status=status;
   }

   public String toString()
   {
      String statusSt ="State Land";
      if (status == 'P')
      {
         statusSt = "Private Land";
      }  
      String objStr = String .format("%-20s%-15.2f%-20d%-15s",farmName,space,proteas,statusSt);
   
      return objStr;
   }

   public boolean isLegal()
   {
      boolean legal = false;
      int numProteasShouldBe =(int) (proteas /(space * 100));
      if (numProteasShouldBe <= 5)
      {
         legal = true;
      }
      return legal;
   }

}