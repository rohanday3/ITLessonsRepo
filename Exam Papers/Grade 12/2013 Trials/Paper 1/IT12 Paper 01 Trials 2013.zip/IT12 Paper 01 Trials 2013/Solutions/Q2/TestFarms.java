import java.util.Scanner;   
import java.io.*;
   
public class TestFarms
{
   public static void main(String args[])
   {
      Farms [] arrFarms = new Farms[50];
      int c  = 0;
   
      try
      {
         Scanner sc = new Scanner (new FileReader("Farms.txt"));
         while(sc.hasNext())
         {
            String line = sc.nextLine();
            Scanner scLine = new Scanner (line).useDelimiter("#|;");
               
            String farmName = scLine.next();
            double space = scLine.nextDouble();
            int proteas = scLine.nextInt();
            char status = scLine.next().charAt(0);
               
            scLine.close();
               
            arrFarms[c] = new Farms(farmName,space,proteas,status);
            c++;
         }
         sc.close(); 
      }
      catch(Exception e)
      {
         System.out.println("Error:"+e.getMessage());
         System.exit(0);
      }
   
   
      Scanner kb = new Scanner(System.in);
      
      char ch = ' ';
      
      do
      {      
         System.out.println();
         System.out.println("              Menu");
         System.out.println();
         System.out.println("       A - Display Sorted Information According to Proteas");
         System.out.println("       B - Display Legal Statistics "); 
         System.out.println("       C - Search for a farm to purchase"); 
         System.out.println();
         System.out.println("       Q - QUIT");
         System.out.println();
         System.out.print("       Your choice? : ");
         ch = kb.nextLine().toUpperCase().charAt(0);
      
         switch (ch)
         {
            case 'A':
               {					
                  for (int i = 0;i<c-1;i++)
                  {
                     for (int j = i+1;j<c;j++)
                     {
                        if (arrFarms[i].getProteas()<arrFarms[j].getProteas())
                        {
                           Farms tempObj = arrFarms[i];
                           arrFarms[i]=arrFarms[j];
                           arrFarms[j]=tempObj;
                        }
                     }
                  }
                  
                  System.out.println(String.format("%-20s%-15s%-20s%-15s","Farm Name","Space Used","Number of Proteas","Land Status"));
                  for (int i = 0;i<c;i++)
                  {
                     System.out.println(arrFarms[i].toString());
                  }
               
                  break;
               }
            
            case 'B':
               {
                  System.out.println(String.format("%-20s%-15s","Farm Name","Statistics"));
                  for (int i = 0;i<c;i++)
                  {
                     String stats = "Illegal";
                     if (arrFarms[i].isLegal())
                     {
                        stats = "Legal";
                     }
                     System.out.println(String.format("%-20s%-15s",arrFarms[i].getFarmName(),stats));
                  }
               
                  break; 
               }
            
            case 'C':
               {
                  System.out.print("Enter the name of the farm to purchase ? ");
                  String farmNameToPurchase = kb.nextLine();
               
                  boolean found = false;
                  int p = 0;
                  while (found==false && p<c)
                  {
                     if (farmNameToPurchase.equalsIgnoreCase(arrFarms[p].getFarmName()))
                     {
                        if (arrFarms[p].getStatus() == 'P')
                        {
                           found = true; 
                           arrFarms[p].setStatus('S');
                           System.out.println("The purchase has been successfully completed");
                        }
                        else
                        {
                           System.out.println("The purchase has been unsuccessful as the farm belongs to the state");
                        
                        }
                     }
                     p++;
                  }
                  if (found == false)
                  {
                     System.out.println("The purchase was not processed as the farm name does not exist");
                  }
               
                  break; 
               } 
            
            case 'Q':
               {
                  System.out.println("Done");
                  break;
               }
            
            default:
               {
                  System.out.println();          
                  System.out.println("Invalid Option!");
                  break;
               }
         } 
      
      }while (ch != 'Q'); 
   
   } 

      
}    
      
      
