
import java.sql.SQLException;
import java.util.Scanner;

public class TestQuestion1XXXX
{
   public static void main (String[] args) throws SQLException
   {
   
      RedData1XXXX DB = new RedData1XXXX();
   
      Scanner kb = new Scanner (System.in);
   
      String sql = "";
   
      char choice = ' '; 
      do
      {         
         System.out.println();
         System.out.println();
         System.out.println("      MENU");
         System.out.println();
         System.out.println("    A - Display Plants");
         System.out.println("    B - Total Endangered");
         System.out.println("    C - Status2012 Not Captured");
         System.out.println("    D - Winter Survey");
         System.out.println("    E - State Land WP");
         System.out.println("    F - Edit KZN state land");
         System.out.println("    G - Remove Site");
         System.out.println();
         System.out.println("    Q - QUIT");
         System.out.println();
         System.out.print("    Your choice? ");
         choice = kb.nextLine().toUpperCase().charAt(0);
         System.out.println();
                           
         switch(choice)
         {
            //=============================================================================
            case 'A':	// Question 1.1
               {
                  sql = "SELECT * FROM PlantsTbl WHERE  Status2012 IN ('EN','CR') ORDER BY Genus, Species;";
                  DB.query(sql);
                  break;
               }
            //=============================================================================
            case 'B':	// Question 1.2
               {
                  sql = "SELECT Genus,Count(*) AS VUCount FROM PlantsTbl where Status2012='VU' GROUP BY Genus;";
                  DB.query(sql);
                  break;
               }
            //=============================================================================
            case 'C': 	// Question 1.3
               {
                  sql = "Select ID, Genus, Site From PlantsTbl where Status2012 is null;";  
                  DB.query(sql);
                  break;
               }               
            //=============================================================================
            case 'D':	// Question 1.4
               {
                  sql = "SELECT SiteID,Supervisor, Month(DateCompleted) AS MonthNumber FROM SitesTbl WHERE Month(DateCompleted)IN (6, 7);";
                  DB.query(sql);
                  break;
               }
            //=============================================================================
            case 'E':	// Question 1.5
               {	
                  sql = "SELECT Genus,Species,Status2012,SiteID FROM PlantsTbl,SitesTbl WHERE PlantsTbl.Site=SitesTbl.SiteID AND StateLand=True And Status2012='CR' And SiteID Like 'WP%';";  				
                  DB.query(sql);
                  break;
               }
            //=============================================================================
            case 'F':	// Question 1.6
               {
                  sql = "Update SitesTbl set StateLand = true where SiteID like 'KZ%';";
                  DB.query(sql);
                  break;
               }
            //=============================================================================
            case 'G':	// Question 1.7
               {
                  System.out.print("Enter the site id to delete ?  ");
                  String siteId = kb.nextLine();
                  
                  sql = "Delete from SitesTbl where SiteID = '"+siteId+"';";  
                  DB.query(sql);
                  break;
               } 			
            //=============================================================================
            case 'Q':
               {
                  DB.disconnect();
                  System.out.println("Done");
                  break;
               }
            
            default:
               {
                  System.out.println();          
                  System.out.println("Invalid Option!");
                  break;
               }
         
         }        
      }while (choice != 'Q');  
   
        
   }
}