import java.io.*;
import java.util.Scanner;  

public class TreeFacts
{
   String[] arrTrees = {
      "Trees are the longest living organisms on earth.",
      "A mature leafy tree produces oxygen for 10 people to inhale in a year.",
      "An average tree absorbs approx. 2000 liters of water every year.",
      "A single edition of a major daily newspaper uses wood from 500 trees.",
      "It takes about 1000 years for a branches height on the trunk to move up by 10 inches.",
      "The Global Prizes Campaign keeps a list of the world's threatened and endangered trees.",
      "We can positively impact tree conservation by buying wood products from sustainable resources only.",
      "An average size tree produces enough oxygen in one year to keep a family of four breathing.",
      "There are currently 1000 tree species that are Critically Endangered.",
      "Trees help us to relax, can lower heart rates, and reduce stress."};


   public void optionA()
   {
      System.out.println(String.format("%-100s%-20s","Facts about trees","Number of words"));
      
      for (int i = 0;i<10;i++)
      {
         String line = arrTrees[i];
         int countWords  = 1;
         for (int j=0;j<line.length();j++)
         {
            if (line.charAt(j) == ' ')
            {
               countWords++;
            }
         }
         System.out.println(String.format("%-100s%-20s",line,countWords));
      }
   }
	
   
   public void optionB()
   {
      for (int i = 0;i<10;i++)
      {
         String line = arrTrees[i];
         String encrypt ="";
         
         for(int j=0;j<line.length();j++)
         {
            char ch = line.charAt(j);
            if (ch == 'Z')
            {
               ch='A';
            }   
            else
            {
               if (ch=='z')
               {
                  ch ='a';
               }
               else
               {
                  if (Character.isLetter(ch))
                  {
                     ch++;
                  }
               }
            }
            encrypt = encrypt + ch;
         
         }
         System.out.println(arrTrees[i]);
         System.out.println(encrypt);
         System.out.println();
      }
   }
	
     	
   public void optionC()
   {
      try
      {
         PrintWriter out = new PrintWriter(new FileWriter("TreeFacts.txt"));
         for (int i = 0;i<10;i++)
         {
            String line = arrTrees[i].substring(1);
            line = line.replaceAll("[AEIOUaeiuo]","");
            line = arrTrees[i].charAt(0)+line;
            out.println(line);
         }
         out.close();
         System.out.println("TreeFacts has been successfully saved");
         
      }
      catch(Exception e)
      {
         System.out.println("Error:"+e.getMessage());
      }
   }
	
   public void optionD()
   {
      String [] dummy = new String [10];
      
      int count = 0;
            
        
      for (int i = 0;i<10;i++)
      {
         String line= arrTrees[i].toLowerCase();
       
         if (!(line.indexOf("endangered")>0))
         {
            dummy[count] = arrTrees[i];
            count++;
         }
      }
   	
      arrTrees = dummy;
      
      System.out.println("Tree Facts without 'endangered'");
      System.out.println();
      for (int i = 0;i<count;i++)
      {
         System.out.println(arrTrees[i]);
      }
   	
   }

   public static void main (String [] args)throws IOException 
   {
      TreeFacts obj = new TreeFacts();
   
      Scanner kb = new Scanner(System.in);
      
      char ch = ' ';
      
      do
      {
         System.out.println();
         System.out.println();
         System.out.println("              Menu");
         System.out.println();
         System.out.println("     Option A");
         System.out.println("     Option B"); 
         System.out.println("     Option C");
         System.out.println("     Option D"); 
         System.out.println();
         System.out.println("     Q - QUIT");
         System.out.println();
         System.out.print("     Your choice? ");
         ch = kb.nextLine().toUpperCase().charAt(0);
         System.out.println();
         System.out.println();
      
         switch (ch)
         {
            case 'A':
               {					
                  obj.optionA();
                  break;
               }
            
            case 'B':
               {
                  obj.optionB();
                  break; 
               }
            
            case 'C':
               {
                  obj.optionC();
                  break; 
               }
            
            case 'D':
               {
                  obj.optionD();
                  break; 
               }  
            
            case 'Q':
               {
                  System.out.println("Done");
                  break;
               }
            
            default:
               {
                  System.out.println();          
                  System.out.println("Invalid Option!");
                  break;
               }
         } 
      
      }while (ch != 'Q'); 
   
   }
}