
public class FarmsXXXX
{
   private String farmName;
   private double space;
   private int proteas;
   private char status;


   public FarmsXXXX(String farmName, double space, int proteas, char status)
   {
   
   }



   public String toString()
   {
      
      String objStr=""; 
   
      return objStr;
   }

     
     
}