
import java.util.Scanner; 
import java.io.*;  

public class TestFarmsXXXX
{
   public static void main(String args[])
   {
     
     
     
     
      Scanner kb = new Scanner(System.in);
      
      char ch = ' ';
      
      do
      {
         System.out.println();
         System.out.println();
         System.out.println("              Menu");
         System.out.println();
         System.out.println("       A - Display Sorted Information According to Proteas");
         System.out.println("       B - Display Legal Statistics "); 
         System.out.println("       C - Search for a farm to purchase"); 
         System.out.println();
         System.out.println("       Q - QUIT");
         System.out.println();
         System.out.print("       Your choice? : ");
         ch = kb.nextLine().toUpperCase().charAt(0);
      
         switch (ch)
         {
            case 'A':
               {					
                  
                  break;
               }
            
            case 'B':
               {
                  
                  break; 
               }
            
            case 'C':
               {
                  
                  break; 
               } 
            
            case 'Q':
               {
                  System.out.println("Done");
                  break;
               }
            
            default:
               {
                  System.out.println();          
                  System.out.println("Invalid Option!");
                  break;
               }
         } 
      
      }while (ch != 'Q'); 
   
   } 

}