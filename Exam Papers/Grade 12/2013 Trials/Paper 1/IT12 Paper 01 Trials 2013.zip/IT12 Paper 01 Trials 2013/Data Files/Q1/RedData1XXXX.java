import java.sql.*;
     
public class RedData1XXXX
{
   Connection conn;
   
   public RedData1XXXX ()
   {
      String filename="RedDataDB.mdb";  //<-- database filename
   
      try
      {
         Class.forName ("sun.jdbc.odbc.JdbcOdbcDriver");
         conn = DriverManager.getConnection ("jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ="+filename.trim()+";READONLY=false");
      }
      catch (Exception e)
      {
         System.out.println(e.toString());
         System.exit(0);
      }
   } 
   
       
   public void display (String sql) throws SQLException
   {
      System.out.println();
      System.out.println();
      
      Statement stmt = conn.createStatement();//ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY
      ResultSet rs = stmt.executeQuery (sql);
      ResultSetMetaData rsm = rs.getMetaData();
         
      int colCount = rsm.getColumnCount();
         
      String colNames[] = new String[colCount];
      String colTypes[] = new String[colCount];
      int colWidths[] = new int[colCount];
         
      for (int i = 1; i <= colCount; i++)
      {
         colNames[i-1] = rsm.getColumnName(i);
         colTypes[i-1] = rsm.getColumnTypeName(i);
      }        
        
      int totalLength = 0;
                  
      for (int i = 1; i <= colCount; i++)
      {
         String longestValue = colNames[i-1];
         rs = stmt.executeQuery (sql);
         //rs.beforeFirst();
            
         while (rs.next ())
         {
            String fieldValue = rs.getString(i);
            if(rs.wasNull())
            {
               fieldValue="";
            }            
            	     
            if (colTypes[i-1].equals("DATETIME"))
            {
               fieldValue = fieldValue.substring(0,11);
            }
               
            if(colTypes[i-1].equals("BIT"))
            {
               if ( rs.getInt(i) == 1)
               {
                  fieldValue = "Yes"; 
               }
               else
               {
                  fieldValue = "No";
               }
            }
            
            if (fieldValue.length() > longestValue.length())
            {
               longestValue = fieldValue;
            }
         }
           
         colWidths[i-1] = longestValue.length() + 3;       	
         totalLength = totalLength + colWidths[i-1];
      }
        
      String headings="";
      for (int i = 1; i <= colCount; i++)
      {
         headings = headings + String.format("%-" + colWidths[i-1] + "s", colNames[i-1]);
      }
      System.out.println(headings);
          
      String underLine="";
      for (int i = 0; i < totalLength; i++)
      {
         underLine = underLine + "=";
      } 
      System.out.println(underLine);
         
      rs = stmt.executeQuery (sql);
      //rs.beforeFirst();  
      
      while (rs.next ())
      { 
         String valueLine="";
         for (int i = 1; i <= colCount; i++)
         {
            if (colTypes[i-1].equals("INT")||colTypes[i-1].equals("SMALLINT")||colTypes[i-1].equals("INTEGER"))
            {
               int value = rs.getInt(i);
               valueLine = valueLine + String.format("%-" + colWidths[i-1] + "d", value);
            }
               
            if (colTypes[i-1].equals("DOUBLE"))
            {
               double value = rs.getDouble(i);
               valueLine = valueLine + String.format("%-" + colWidths[i-1] + ".2f", value);
            }
                              
            if (colTypes[i-1].equals("CURRENCY"))
            {
               double value = rs.getDouble(i);
               valueLine = valueLine + "R " + String.format("%-" + (colWidths[i-1]-2) + ".2f", value);
            }
               
            if (colTypes[i-1].equals("DATETIME"))
            {
               String value = rs.getString(i).substring(0,11); 
               valueLine = valueLine + String.format("%-" + colWidths[i-1] + "s", value);
            }
                              
            if(colTypes[i-1].equals("BIT"))
            {
               String value = "";                
               if ( rs.getInt(i) == 1)
               {
                  value = "Yes";
               }
               else
               {
                  value = "No";
               }
               valueLine = valueLine + String.format("%-" + colWidths[i-1] + "s", value);
            }
               				
            if (colTypes[i-1].equals("VARCHAR"))
            {
               String value = rs.getString(i);
               valueLine = valueLine + String.format("%-" + colWidths[i-1] + "s", value);
            }   
                           
         }
         System.out.println(valueLine);
         
      }
      rs.close();  
      stmt.close ();
   }
   	                        	
        
   public void query(String sql) throws SQLException
   {
      if (sql.toUpperCase().substring(0,10).contains("INSERT"))
      {
         eU(sql);         
         System.out.println("Record Added Successfully");   
      }
      
      if (sql.toUpperCase().substring(0,10).contains("DELETE"))
      {
         eU(sql);       
         System.out.println("Record/s Removed Successfully");
      }
      
      if (sql.toUpperCase().substring(0,10).contains("UPDATE"))
      {
         eU(sql);        
         System.out.println("Record/s Edited Successfully");
      }
           
      if (sql.toUpperCase().substring(0,10).contains("SELECT"))
      {
         display(sql);
      }
   
   }

   
   public void eU(String sql) throws SQLException
   {
      Statement stmt = conn.createStatement();				
      stmt.executeUpdate (sql);
      stmt.close ();
   }

      
   public void disconnect() throws SQLException
   {
      conn.close ();
   }

}
    
  
