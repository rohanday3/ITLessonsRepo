
import java.sql.SQLException;
import java.util.Scanner;

public class TestQuestion1XXXX
{
   public static void main (String[] args) throws SQLException
   {
   
      RedData1XXXX DB = new RedData1XXXX();
   
      Scanner kb = new Scanner (System.in);
   
      String sql = "";
   
      char choice = ' '; 
      do
      {         
         System.out.println();
         System.out.println();
         System.out.println("      MENU");
         System.out.println();
         System.out.println("    A - Display Plants");
         System.out.println("    B - Total Endangered");
         System.out.println("    C - Status2012 Not Captured");
         System.out.println("    D - Winter Survey");
         System.out.println("    E - State Land WP");
         System.out.println("    F - Edit KZN state land");
         System.out.println("    G - Remove Site");
         System.out.println();
         System.out.println("    Q - QUIT");
         System.out.println();
         System.out.print("    Your choice? ");
         choice = kb.nextLine().toUpperCase().charAt(0);
         System.out.println();
                           
         switch(choice)
         {
            //=============================================================================
            case 'A':	// Question 1.1
               {
                  sql = "";
                  DB.query(sql);
                  break;
               }
            //=============================================================================
            case 'B':	// Question 1.2
               {
                  sql = "";
                  DB.query(sql);
                  break;
               }
            //=============================================================================
            case 'C': 	// Question 1.3
               {
                  sql = "";  
                  DB.query(sql);
                  break;
               }               
            //=============================================================================
            case 'D':	// Question 1.4
               {
                  sql = "";
                  DB.query(sql);
                  break;
               }
            //=============================================================================
            case 'E':	// Question 1.5
               {	
                  sql = "";  				
                  DB.query(sql);
                  break;
               }
            //=============================================================================
            case 'F':	// Question 1.6
               {
                  sql = "";
                  DB.query(sql);
                  break;
               }
            //=============================================================================
            case 'G':	// Question 1.7
               {
                  System.out.print("Enter the site id to delete ?  ");
                  String siteId = kb.nextLine();
                  
                  sql = "";  
                  DB.query(sql);
                  break;
               } 			
            //=============================================================================
            case 'Q':
               {
                  DB.disconnect();
                  System.out.println("Done");
                  break;
               }
            
            default:
               {
                  System.out.println();          
                  System.out.println("Invalid Option!");
                  break;
               }
         
         }        
      }while (choice != 'Q');  
   
        
   }
}